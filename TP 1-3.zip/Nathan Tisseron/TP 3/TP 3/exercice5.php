<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 5</title>
</head>
<body>
    <form method="get" action="affiche_exo5.php">
        <!-- Liste déroulante pour les jours -->
        <label for="jour">Jour:</label>
        <select name="jour" id="jour">
            <?php
            for ($jour = 1; $jour <= 31; $jour++) {
                echo "<option value='$jour'>$jour</option>";
            }
            ?>
        </select>
        <br>

        <!-- Liste déroulante pour les mois -->
        <label for="mois">Mois:</label>
        <select name="mois" id="mois">
            <?php
            $mois = [
                "Janvier" => 1, "Février" => 2, "Mars" => 3, "Avril" => 4,
                "Mai" => 5, "Juin" => 6, "Juillet" => 7, "Août" => 8,
                "Septembre" => 9, "Octobre" => 10, "Novembre" => 11, "Décembre" => 12
            ];
            foreach ($mois as $nom => $num) {
                echo "<option value='$num'>$nom</option>";
            }
            ?>
        </select>
        <br>

        <!-- Liste déroulante pour les années -->
        <label for="annee">Année:</label>
        <select name="annee" id="annee">
            <?php
            for ($annee = 1980; $annee <= 2005; $annee++) {
                echo "<option value='$annee'>$annee</option>";
            }
            ?>
        </select>
        <br>

        <input type="submit" value="Envoyer">
    </form>
</body>
</html>