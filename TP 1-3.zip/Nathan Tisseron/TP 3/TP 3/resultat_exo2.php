<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Résultat du test</title>
</head>
<body>
    <h1>Résultat du test</h1>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre = $_POST['nombre'];
        $borne_min = $_POST['borne_min'];
        $borne_max = $_POST['borne_max'];

        if ($borne_min > $borne_max) {
            // Échangez les valeurs si le minimum est supérieur au maximum
            $temp = $borne_min;
            $borne_min = $borne_max;
            $borne_max = $temp;
        }

        echo "'$nombre' est-il compris entre '$borne_min' et '$borne_max' ?<br>";

        if ($nombre >= $borne_min && $nombre <= $borne_max) {
            echo "Oui, '$nombre' est compris entre '$borne_min' et '$borne_max'.";
        } else {
            echo "Non, '$nombre' n'est pas compris entre '$borne_min' et '$borne_max'.";
        }
    } else {
        echo "Aucune donnée n'a été soumise.";
    }
    ?>
</body>
</html>