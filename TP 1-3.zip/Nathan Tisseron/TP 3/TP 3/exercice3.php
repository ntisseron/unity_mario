<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 3</title>
</head>
<body>
    <!-- Formulaire pour demander L, C et B -->
    <form method="post" action="">
        <label for="lignes">Nombre de lignes (L) :</label>
        <input type="number" id="lignes" name="lignes" required><br>
        
        <label for="colonnes">Nombre de colonnes (C) :</label>
        <input type="number" id="colonnes" name="colonnes" required><br>
        
        <label for="bordure">Taille de la bordure (B) en pixels :</label>
        <input type="number" id="bordure" name="bordure" required><br>
        
        <input type="submit" value="Générer le tableau">
    </form>

    <?php
    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Récupérer les valeurs du formulaire
        $lignes = (int)$_POST['lignes'];
        $colonnes = (int)$_POST['colonnes'];
        $bordure = (int)$_POST['bordure'];

        // Générer le tableau
        echo "<table border='$bordure'>";
        for ($i = 0; $i < $lignes; $i++) {
            echo "<tr>";
            for ($j = 0; $j < $colonnes; $j++) {
                echo "<td>&nbsp;</td>";  // cellule vide
            }
            echo "</tr>";
        }
        echo "</table>";
    }
    ?>
</body>
</html>