<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Date Choisie</title>
</head>
<body>
    <?php
    if (isset($_GET['jour']) && isset($_GET['mois']) && isset($_GET['annee'])) {
        $jour = intval($_GET['jour']);
        $mois = intval($_GET['mois']);
        $annee = intval($_GET['annee']);

        echo "La date choisie est le $jour/$mois/$annee.";
    } else {
        echo "Aucune date n'a été choisie.";
    }
    ?>
</body>
</html>