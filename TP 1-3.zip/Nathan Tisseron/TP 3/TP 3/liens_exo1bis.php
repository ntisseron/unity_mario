<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liens_exo1bis</title>
</head>
<body>
    <h2>Consultation de :</h2>
    <ul>
        <li><a href="etat_civil_exo1bis.php?prenom=<?php echo $_GET['prenom']; ?>&nom=<?php echo $_GET['nom']; ?>">votre état civil</a></li>
        <li><a href="adresse_exo1bis.php?adresse=<?php echo $_GET['adresse']; ?>&ville=<?php echo $_GET['ville']; ?>&code_postal=<?php echo $_GET['code_postal']; ?>">votre adresse</a></li>
    </ul>
</body>
</html>