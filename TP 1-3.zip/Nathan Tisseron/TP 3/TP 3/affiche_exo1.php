<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Affichage des Données Exercice 1</title>
</head>
<body>
    <?php
    // Récupération des données du formulaire
    $prenom = htmlspecialchars($_POST['prenom']);
    $nom = htmlspecialchars($_POST['nom']);
    $adresse = htmlspecialchars($_POST['adresse']);
    $ville = htmlspecialchars($_POST['ville']);
    $code_postal = htmlspecialchars($_POST['code_postal']);

    // Affichage des données
    echo "Bienvenue $prenom $nom.<br>";
    echo "Nous avons bien noté que vous habitez<br>";
    echo "$adresse à $ville ($code_postal).";
    ?>
</body>
</html>