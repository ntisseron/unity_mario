<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 1</title>
</head>
<body>
    <form action="affiche_exo1.php" method="post">
        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom"><br><br>
        
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom"><br><br>
        
        <label for="adresse">Adresse :</label>
        <input type="text" id="adresse" name="adresse"><br><br>
        
        <label for="ville">Ville :</label>
        <input type="text" id="ville" name="ville"><br><br>
        
        <label for="code_postal">Code Postal :</label>
        <input type="text" id="code_postal" name="code_postal"><br><br>
        
        <input type="submit" value="Envoyer">
        <input type="reset" value="Réinitialiser">
    </form>
</body>
</html>