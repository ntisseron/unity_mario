<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 6</title>
</head>
<body>
    <form action="affiche_exo6.php" method="post">
        <?php
        // Exercice 6 : Création de liste de bouton radio
        $loisirs = ["Musique", "Sport", "Lecture", "Voyage", "Cinéma"];

        // Génération des boutons radio à partir du tableau
        foreach ($loisirs as $loisir) {
            echo "<input type='radio' name='loisir' value='$loisir'> $loisir<br>";
        }
        ?>
        <input type="submit" value="Envoyer">
    </form>
</body>
</html>