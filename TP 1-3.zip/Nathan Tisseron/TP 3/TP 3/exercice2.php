<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 2</title>
</head>
<body>
    <h1>Entrez les nombres</h1>
    <form action="resultat_exo2.php" method="POST">
        <label for="nombre">Nombre à tester :</label>
        <input type="number" id="nombre" name="nombre" required>
        <br><br>
        <label for="borne_min">Borne minimale :</label>
        <input type="number" id="borne_min" name="borne_min" required>
        <br><br>
        <label for="borne_max">Borne maximale :</label>
        <input type="number" id="borne_max" name="borne_max" required>
        <br><br>
        <input type="submit" value="Tester">
    </form>
</body>
</html>