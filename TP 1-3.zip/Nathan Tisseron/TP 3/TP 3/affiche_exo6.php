<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Affichage du Loisir Favori</title>
</head>
<body>
    <?php
    // Vérification que le formulaire a été soumis et qu'un loisir a été choisi
    if (isset($_POST['loisir'])) {
        $loisirFavori = htmlspecialchars($_POST['loisir']);
        echo "Votre loisir favori est : $loisirFavori";
    } else {
        echo "Aucun loisir n'a été choisi.";
    }
    ?>
</body>
</html>