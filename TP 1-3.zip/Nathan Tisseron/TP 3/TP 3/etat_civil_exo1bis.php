<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>État Civil</title>
</head>
<body>
    <h2>État Civil</h2>
    <p>Prénom : <?php echo htmlspecialchars($_GET['prenom']); ?></p>
    <p>Nom : <?php echo htmlspecialchars($_GET['nom']); ?></p>
</body>
</html>