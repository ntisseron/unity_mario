<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Affichage des Loisirs</title>
</head>
<body>
    <?php
    // Vérifier si le tableau des loisirs est défini et non vide
    if (isset($_POST['loisirs']) && !empty($_POST['loisirs'])) {
        // Récupérer et trier les loisirs
        $loisirsChoisis = $_POST['loisirs'];
        sort($loisirsChoisis);
        
        // Afficher les loisirs choisis
        echo "Vous pratiquez aussi comme loisirs : " . implode(" - ", $loisirsChoisis) . ".";
    } else {
        echo "Vous n'avez sélectionné aucun loisir.";
    }
    ?>
</body>
</html>