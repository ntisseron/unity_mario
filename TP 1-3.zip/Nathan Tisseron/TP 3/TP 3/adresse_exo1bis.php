<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Adresse</title>
</head>
<body>
    <h2>Adresse</h2>
    <p>Vous habitez :</p>
    <p><?php echo htmlspecialchars($_GET['adresse']); ?></p>
    <p><?php echo htmlspecialchars($_GET['ville']); ?></p>
    <p><?php echo htmlspecialchars($_GET['code_postal']); ?></p>
</body>
</html>
