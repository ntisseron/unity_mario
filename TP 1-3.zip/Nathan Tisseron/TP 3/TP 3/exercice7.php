<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 7</title>
</head>
<body>
    <form action="affiche_exo7.php" method="post">
        <?php
        // Exercice 7 : Création de liste de cases à cocher
        // Tableau des loisirs
        $loisirs = ["Jeux", "Sports", "Voyages", "Lecture", "Musique", "Cinéma"];
        
        // Affichage des cases à cocher
        foreach ($loisirs as $loisir) {
            echo "<input type='checkbox' name='loisirs[]' value='$loisir'> $loisir<br>";
        }
        ?>
        <input type="submit" value="Envoyer">
    </form>
</body>
</html>