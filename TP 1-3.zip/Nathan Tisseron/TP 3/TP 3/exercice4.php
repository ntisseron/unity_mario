<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices TP3 - Exercice 4</title>
</head>
<body>
    <?php
    // Affichage de Texte en PHP
    echo "Ceci est une ligne créée uniquement en PHP<br>";
    echo "Ceci est la 2ème phrase créée avec PHP<br>";
    echo '<a href="https://www.unesco.org/fr">Lien vers le site de l\'UNESCO</a><br><br>';

    // HTML Dynamique
    $nom = "Votre Nom";
    $prenom = "Votre Prénom";
    $lienTexte = "Aller à la page suivante";
    $lienURL = "page_suivante.php";
    echo "<h1>Bienvenue</h1>";
    echo "<p>Nom: $nom</p>";
    echo "<p>Prénom: $prenom</p>";
    echo "<a href='$lienURL'>$lienTexte</a><br><br>";

    // Formater le Texte
    echo "<p><strong><em>Ce texte est en gras et en italique.</em></strong></p>";

    $elementsOrdonnees = ["Élément 1", "Élément 2", "Élément 3"];
    $elementsNonOrdonees = ["Item A", "Item B", "Item C"];

    echo "<ol>";
    foreach ($elementsOrdonnees as $element) {
        echo "<li>$element</li>";
    }
    echo "</ol>";

    echo "<ul>";
    foreach ($elementsNonOrdonees as $item) {
        echo "<li>$item</li>";
    }
    echo "</ul>";
    ?>

    <!-- Exercice 4 : Formulaire et vérification d'identité -->
    <?php
    // Identifiants en dur
    $storedUsername = "utilisateur";
    $storedPassword = "motdepasse";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = trim($_POST["username"]);
        $password = trim($_POST["password"]);

        if (strcasecmp($username, $storedUsername) == 0 && strcasecmp($password, $storedPassword) == 0) {
            echo "<h2>Bienvenue, $username!</h2>";
        } else {
            echo '<form method="post" action="">
                    <label for="username">Nom:</label>
                    <input type="text" id="username" name="username" required><br>
                    <label for="password">Mot de passe:</label>
                    <input type="password" id="password" name="password" required><br>
                    <input type="submit" value="Soumettre">
                  </form>';
        }
    } else {
        echo '<form method="post" action="">
                <label for="username">Nom:</label>
                <input type="text" id="username" name="username" required><br>
                <label for="password">Mot de passe:</label>
                <input type="password" id="password" name="password" required><br>
                <input type="submit" value="Soumettre">
              </form>';
    }
    ?>
</body>
</html>
