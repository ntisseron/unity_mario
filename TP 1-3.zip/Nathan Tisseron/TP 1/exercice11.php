<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 11</title>
</head>
<body>
    <?php
    // Exercice 11 : Conversion des Montants

    // 1. Initialiser un tableau de 4 cases contenant des montants en francs.
    $montants_francs = [100, 200, 300, 400];

    // 2. Convertir les montants en euros en utilisant une procédure.
    function convertirEnEuros($montants)
    {
        $taux_conversion = 0.1524; // Taux de conversion francs -> euros
        $montants_euros = array();
        foreach ($montants as $montant) {
            $montants_euros[] = $montant * $taux_conversion;
        }
        return $montants_euros;
    }

    // 3. Afficher la somme totale en euros ainsi que chaque case du tableau.
    $montants_euros = convertirEnEuros($montants_francs);
    $somme_totale_euros = array_sum($montants_euros);

    echo "Somme totale en euros : " . $somme_totale_euros . " €<br>";
    echo "Montants en euros : " . implode(", ", $montants_euros) . " €<br><br>";

    // Exercice 11.2 : Conversion de Devises

    // 1. Demander à l'utilisateur de saisir un montant en euros.
    $montant_euros = 150;

    // 2. Convertir ce montant en dollars américains et en livres sterling.
    $taux_conversion_usd = 1.18; // Taux de conversion euros -> dollars américains
    $taux_conversion_gbp = 0.86; // Taux de conversion euros -> livres sterling

    $montant_usd = $montant_euros * $taux_conversion_usd;
    $montant_gbp = $montant_euros * $taux_conversion_gbp;

    echo "Montant en euros : $montant_euros €<br>";
    echo "Montant en dollars américains : $montant_usd USD<br>";
    echo "Montant en livres sterling : $montant_gbp GBP<br><br>";

    // Exercice 11.3 : Historique des Conversions

    // 1. Créer un fichier texte pour enregistrer les conversions.
    $fichier = fopen("conversions_exo11.txt", "a");

    // 2. Ajouter chaque conversion au fichier avec la date et l'heure.
    $date_heure = date("Y-m-d H:i:s");
    $conversion = "Conversion du montant $montant_euros € en $montant_usd USD et $montant_gbp GBP";
    fwrite($fichier, "$date_heure : $conversion\n");

    fclose($fichier);
    ?>
</body>
</html>