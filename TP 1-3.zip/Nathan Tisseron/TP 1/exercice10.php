<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 10</title>
</head>
<body>
    <?php
    // Exercice 10 : Utilisation des Tableaux et Fonctions

    // 1. Initialiser un tableau de 4 cases contenant des nombres
    $nombres = [10, 20, 30, 40];

    // 2. Calculer et afficher la somme des éléments du tableau

    // Sans fonction
    $sommeSansFonction = 0;
    foreach ($nombres as $nombre) {
        $sommeSansFonction += $nombre;
    }
    echo "Somme sans fonction: $sommeSansFonction<br>";

    // En créant une fonction somme
    function somme($tableau) {
        $total = 0;
        foreach ($tableau as $element) {
            $total += $element;
        }
        return $total;
    }
    echo "Somme avec fonction: " . somme($nombres) . "<br>";

    // En créant un fichier spécifique contenant la fonction somme
    require 'fonctions_exo10.php';
    echo "Somme avec fonction définie dans un fichier externe: " . somme($nombres) . "<br><br>";

    // Exercice 10.2 : Tableaux Associatifs

    // 1. Créer un tableau associatif avec des informations sur des étudiants (nom, âge, note)
    $etudiants = [
        ["nom" => "Alice", "age" => 20, "note" => 15],
        ["nom" => "Bob", "age" => 22, "note" => 18],
        ["nom" => "Claire", "age" => 21, "note" => 14]
    ];

    // 2. Afficher les informations de chaque étudiant
    foreach ($etudiants as $etudiant) {
        echo "Nom: " . $etudiant['nom'] . ", Age: " . $etudiant['age'] . ", Note: " . $etudiant['note'] . "<br>";
    }
    echo "<br>";

    // Exercice 10.3 : Tri de Tableaux

    // 1. Initialiser un tableau avec des nombres aléatoires
    $nombresAleatoires = [5, 3, 8, 1, 9];

    // 2. Trier le tableau par ordre croissant et décroissant et afficher les résultats
    sort($nombresAleatoires); // Tri par ordre croissant
    echo "Tableau trié par ordre croissant: ";
    print_r($nombresAleatoires);
    echo "<br>";

    rsort($nombresAleatoires); // Tri par ordre décroissant
    echo "Tableau trié par ordre décroissant: ";
    print_r($nombresAleatoires);
    ?>
</body>
</html>