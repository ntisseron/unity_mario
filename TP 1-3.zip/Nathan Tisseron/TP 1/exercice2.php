<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 2</title>
</head>
<body>
    <?php
    // Exercice 2 : Déclaration et Affichage de Variables

    // 1. Déclarer deux variables : nom et prénom
    $nom = "Dupont";
    $prenom = "Louis";

    // 2. Afficher ces valeurs de trois façons différentes

    // Avec deux commandes echo
    echo $nom;
    echo "<br>";
    echo $prenom;
    echo "<br><br>";

    // Avec une seule commande echo et une chaîne de caractères
    echo "Nom: $nom, Prénom: $prenom";
    echo "<br><br>";

    // Avec une commande echo et l'opérateur de concaténation
    echo "Nom: " . $nom . ", Prénom: " . $prenom;
    echo "<br><br>";

    // Exercice 2.2 : Types de Variables

    // 1. Initialiser des variables de différents types
    $entier = 42;
    $flottant = 3.14;
    $chaine = "Bonjour";
    $booleen = true;

    // 2. Afficher ces variables et leurs types respectifs en utilisant var_dump()
    echo "Variable de type entier : ";
    var_dump($entier);
    echo "<br>";

    echo "Variable de type flottant : ";
    var_dump($flottant);
    echo "<br>";

    echo "Variable de type chaîne de caractères : ";
    var_dump($chaine);
    echo "<br>";

    echo "Variable de type booléen : ";
    var_dump($booleen);
    echo "<br><br>";

    // Exercice 2.3 : Variables Dynamiques

    // 1. Déclarer une variable $nom avec la valeur "variable"
    $nom = "variable";

    // 2. Déclarer une variable variable basée sur $nom et lui assigner une valeur
    $$nom = "Ceci est une variable variable";

    // 3. Afficher la valeur de cette variable variable
    echo "Valeur de la variable variable : " . $variable;
    ?>
</body>
</html>
