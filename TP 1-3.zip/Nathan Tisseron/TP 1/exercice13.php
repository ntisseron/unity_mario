<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 13</title>
</head>
<body>
    <?php
    // Exercice 13 : Formulaire de Don pour un Site Caritatif

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupération des données du formulaire
        $nom = $_POST["nom"];
        $age = $_POST["age"];
        $mail = $_POST["mail"];
        $don = $_POST["don"];

        // Enregistrement des informations dans un fichier
        $donnees = "$nom | $age | $mail | $don\n";
        file_put_contents("resultats_exo13.txt", $donnees, FILE_APPEND | LOCK_EX);

        // Affichage d'un message de confirmation
        echo "Merci pour votre don ! Vos informations ont bien été enregistrées.<br>";
        echo "Récapitulatif : Nom: $nom, Age: $age, Mail: $mail, Don: $don €<br><br>";
    }
    
    // Exercice 13.3 : Statistiques des Dons
    
    // Lecture des données du fichier resultats.txt
    $lignes = file("resultats_exo13.txt", FILE_IGNORE_NEW_LINES);
    
    // Initialisation des variables pour les statistiques
    $totalDons = 0;
    $nombreDons = count($lignes);
    
    // Calcul du montant total des dons
    foreach ($lignes as $ligne) {
        $donnees = explode(" | ", $ligne);
        $don = intval($donnees[3]);
        $totalDons += $don;
    }
    
    // Initialisation de la moyenne des dons
    $moyenneDons = 0;
    
    // Vérification s'il y a des dons enregistrés avant de calculer la moyenne
    if ($nombreDons > 0) {
        // Calcul de la moyenne des dons
        $moyenneDons = $totalDons / $nombreDons;
    }
    
    // Affichage des statistiques
    echo "Statistiques des Dons : <br>";
    echo "Montant total des dons : $totalDons €<br>";
    echo "Nombre total de dons : $nombreDons<br>";
    echo "Moyenne des dons : $moyenneDons €<br>";
    ?>
    
    <!-- Exercice 13.1 : Formulaire de Don -->
    <h2>Faire un Don</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        Nom : <input type="text" name="nom"><br>
        Age : <input type="number" name="age"><br>
        Mail : <input type="email" name="mail"><br>
        Valeur du don en euros : <input type="number" name="don"><br>
        <input type="submit" value="Valider">
    </form>
</body>
</html>
