<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 9</title>
</head>
<body>
    <?php
    // Exercice 9 : Compteur de Visites

    // Chemin du fichier de compteur
    $fichierCompteur = "cpt.txt";

    // Exercice 9.1 : Mettre à jour un compteur de visites à chaque chargement de la page

    // Vérifier si le fichier du compteur existe
    if (file_exists($fichierCompteur)) {
        // Lire la valeur actuelle du compteur
        $compteur = file_get_contents($fichierCompteur);
        // Incrémenter le compteur
        $compteur++;
    } else {
        // Initialiser le compteur à 1 si le fichier n'existe pas
        $compteur = 1;
    }

    // Sauvegarder la valeur du compteur dans un fichier
    file_put_contents($fichierCompteur, $compteur);

    // Exercice 9.2 : Affichage du Compteur

    // Afficher le nombre de visites
    echo "Nombre de visites : $compteur<br>";

    // Exercice 9.3 : Réinitialisation du Compteur

    // Vérifier si le bouton de réinitialisation a été soumis
    if (isset($_POST['reset'])) {
        // Réinitialiser le compteur en remettant sa valeur à zéro
        $compteur = 0;
        // Mettre à jour le fichier de compteur avec la nouvelle valeur
        file_put_contents($fichierCompteur, $compteur);
        // Rafraîchir la page pour afficher le compteur réinitialisé
        header("Refresh:0");
    }
    ?>

    <!-- Formulaire pour réinitialiser le compteur -->
    <form method="post">
        <input type="submit" name="reset" value="Réinitialiser le compteur">
    </form>
</body>
</html>