<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 5</title>
</head>
<body>
    <?php
    // Exercice 5 : Boucles en PHP

    // 1. Affecter une valeur à la variable nbre
    $nbre = 10;

    // Afficher la somme des entiers de 1 à nbre en utilisant une boucle FOR
    $sommeFor = 0;
    for ($i = 1; $i <= $nbre; $i++) {
        $sommeFor += $i;
    }
    echo "Somme des entiers de 1 à $nbre (FOR): $sommeFor<br>";

    // Afficher la somme des entiers de 1 à nbre en utilisant une boucle WHILE
    $sommeWhile = 0;
    $i = 1;
    while ($i <= $nbre) {
        $sommeWhile += $i;
        $i++;
    }
    echo "Somme des entiers de 1 à $nbre (WHILE): $sommeWhile<br><br>";

    // Exercice 5.2 : Boucle foreach

    // 1. Initialiser un tableau avec des noms de fruits
    $fruits = ["Pomme", "Banane", "Cerise", "Orange", "Raisin"];

    // Utiliser une boucle foreach pour afficher chaque fruit dans une liste HTML
    echo "Liste de fruits :<ul>";
    foreach ($fruits as $fruit) {
        echo "<li>$fruit</li>";
    }
    echo "</ul><br>";

    // Exercice 5.3 : Boucle Imbriquée

    // 1. Créer un tableau de tableaux représentant une grille de 3x3
    $grille = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];

    // Utiliser des boucles imbriquées pour afficher cette grille dans une table HTML
    echo "<table border='1'>";
    foreach ($grille as $ligne) {
        echo "<tr>";
        foreach ($ligne as $cellule) {
            echo "<td>$cellule</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    ?>
</body>
</html>