<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 14</title>
</head>
<body>
    <?php
    // Exemple de déclaration des variables $dons et $ages
    $dons = [50, 100, 200];
    $ages = [30, 45, 50];

    // Exercice 14.1 : Ajouter un bouton "Résultats" sur la page d'accueil
    echo '<a href="resultats.php"><button>Résultats</button></a>';
    echo "<br><br>";

    // Exercice 14.2 : Afficher chaque don, la somme globale reçue et la moyenne d’âges des donateurs

    // Calcul de la somme des dons
    $sommeDons = array_sum($dons);

    // Calcul de la moyenne d'âges des donateurs
    $moyenneAges = array_sum($ages) / count($ages);

    echo "Somme globale des dons : $sommeDons €<br>";
    echo "Moyenne d'âges des donateurs : $moyenneAges ans<br>";
    echo "<br>";

    // Exercice 14.3 : Export des Données au format CSV

    // Création du fichier CSV
    $csvFileName = "resultats_dons_exo14.csv";
    $csvFile = fopen($csvFileName, 'w');

    // En-tête du fichier CSV
    fputcsv($csvFile, ["Donateur", "Âge", "Montant du Don"]);

    // Écriture des données dans le fichier CSV
    for ($i = 0; $i < count($dons); $i++) {
        fputcsv($csvFile, [$i+1, $ages[$i], $dons[$i]]);
    }

    fclose($csvFile);

    // Afficher un lien pour télécharger le fichier CSV
    echo "<a href='$csvFileName' download>Exporter les résultats au format CSV</a>";
    ?>
</body>
</html>