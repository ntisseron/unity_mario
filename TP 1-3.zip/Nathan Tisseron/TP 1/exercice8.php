<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 8</title>
</head>
<body>
    <?php
    // Exercice 8 : Lecture d'un Fichier Texte

    // 1. Créer un fichier texte calepin.txt avec les informations données
    $fichier = fopen("calepin_exo8.txt", "w");
    fwrite($fichier, "David | Martin | 3, Impasse des Lilas | 64600 | Anglet\n");
    fwrite($fichier, "Etchebane | Amïa | 4, Bld du BAB | 64100 | Bayonne\n");
    fwrite($fichier, "Chirac | Joselyne | 125 avenue Paul Bert | 64200 | Biarritz\n");
    fclose($fichier);

    // 2. Ouvrir le fichier et afficher les informations de manière structurée
    $fichier = fopen("calepin_exo8.txt", "r");
    echo "<h2>Informations du calepin.txt :</h2>";
    while (!feof($fichier)) {
        $ligne = fgets($fichier);
        $infos = explode(" | ", $ligne);
        echo "<p><strong>Nom:</strong> $infos[0], <strong>Prénom:</strong> $infos[1], <strong>Adresse:</strong> $infos[2], <strong>Code Postal:</strong> $infos[3], <strong>Ville:</strong> $infos[4]</p>";
    }
    fclose($fichier);
    echo "<br>";

    // Exercice 8.2 : Ajout d'Entrées dans le Fichier

    // 1. Demander à l'utilisateur d'entrer de nouvelles informations
    $nouvellesInfos = "Smith | John | 10, Rue de Paris | 75001 | Paris";

    // 2. Ajouter ces informations au fichier calepin.txt
    $fichier = fopen("calepin_exo8.txt", "a");
    fwrite($fichier, $nouvellesInfos . "\n");
    fclose($fichier);

    // Exercice 8.3 : Recherche dans le Fichier

    // 1. Permettre à l'utilisateur de rechercher un nom dans le fichier calepin.txt
    $nomRecherche = "Etchebane";

    // 2. Afficher les informations correspondantes si le nom est trouvé
    $fichier = fopen("calepin_exo8.txt", "r");
    echo "<h2>Recherche pour le nom '$nomRecherche' :</h2>";
    while (!feof($fichier)) {
        $ligne = fgets($fichier);
        $infos = explode(" | ", $ligne);
        if ($infos[0] == $nomRecherche) {
            echo "<p><strong>Nom:</strong> $infos[0], <strong>Prénom:</strong> $infos[1], <strong>Adresse:</strong> $infos[2], <strong>Code Postal:</strong> $infos[3], <strong>Ville:</strong> $infos[4]</p>";
        }
    }
    fclose($fichier);
    ?>
</body>
</html>