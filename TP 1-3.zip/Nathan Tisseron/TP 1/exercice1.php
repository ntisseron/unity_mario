<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 1</title>
</head>
<body>
    <?php
    // Exercice 1 : Affichage de Texte en PHP
    echo "Ceci est une ligne créée uniquement en PHP<br>";
    echo "Ceci est la 2ème phrase créée avec PHP<br>";
    echo '<a href="https://www.unesco.org/fr">Lien vers le site de l\'UNESCO</a><br><br>';

    // Exercice 1.2 : HTML Dynamique
    $nom = "Votre Nom";
    $prenom = "Votre Prénom";
    $lienTexte = "Aller à la page suivante";
    $lienURL = "page_suivante.php";
    echo "<h1>Bienvenue</h1>";
    echo "<p>Nom: $nom</p>";
    echo "<p>Prénom: $prenom</p>";
    echo "<a href='$lienURL'>$lienTexte</a><br><br>";

    // Exercice 1.3 : Formater le Texte
    echo "<p><strong><em>Ce texte est en gras et en italique.</em></strong></p>";

    $elementsOrdonnees = ["Élément 1", "Élément 2", "Élément 3"];
    $elementsNonOrdonees = ["Item A", "Item B", "Item C"];

    echo "<ol>";
    foreach ($elementsOrdonnees as $element) {
        echo "<li>$element</li>";
    }
    echo "</ol>";

    echo "<ul>";
    foreach ($elementsNonOrdonees as $item) {
        echo "<li>$item</li>";
    }
    echo "</ul>";
    ?>
</body>
</html>
