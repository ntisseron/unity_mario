<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 6</title>
</head>
<body>
    <?php
    // Exercice 6 : Affichage de la Date et de l'Heure

    // 1. Afficher la date et l'heure du jour
    echo "Nous sommes le : " . date("d/m/Y") . "<br>";
    echo "Il est " . date("H:i") . "<br>";
    echo "Merci<br><br>";

    // Exercice 6.2 : Calcul de l'Âge

    // 1. Demander à l'utilisateur de saisir sa date de naissance (pour l'exemple, on utilise une date fixe)
    $dateNaissance = "1990-05-25"; // Format AAAA-MM-JJ
    $dateActuelle = date("Y-m-d");

    // Calculer l'âge
    $anniversaire = new DateTime($dateNaissance);
    $aujourdhui = new DateTime($dateActuelle);
    $age = $aujourdhui->diff($anniversaire)->y;

    // Afficher l'âge actuel
    echo "Votre date de naissance est le : " . date("d/m/Y", strtotime($dateNaissance)) . "<br>";
    echo "Vous avez " . $age . " ans.<br><br>";

    // Exercice 6.3 : Formatage de Date

    // 1. Afficher la date du jour dans différents formats
    echo "Format Y-m-d : " . date("Y-m-d") . "<br>";
    echo "Format d/m/Y : " . date("d/m/Y") . "<br>";
    echo "Format l jS \\of F Y : " . date("l jS \of F Y") . "<br>";
    ?>
</body>
</html>