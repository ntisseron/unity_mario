<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 3</title>
</head>
<body>
    <?php
    // Exercice 3 : Calculs et Types de Données

    // 1. Créer une balise de titre H1
    echo "<h1>Calcul sur les variables</h1>";

    // 2. Affecter les valeurs 0.206, 150 et 10 aux variables TVA, prix et Nombre
    $TVA = 0.206;
    $prix = 150;
    $nombre = 10;

    // 3. Calculer le prix HT et le prix TTC pour les 10 articles et les afficher
    $prixHT = $prix * $nombre;
    $prixTTC = $prixHT * (1 + $TVA);

    echo "Prix HT pour $nombre articles: " . number_format($prixHT, 2) . " €<br>";
    echo "Prix TTC pour $nombre articles: " . number_format($prixTTC, 2) . " €<br><br>";

    // 4. Afficher également le type de chaque variable
    echo "Type de la variable TVA: ";
    var_dump($TVA);
    echo "<br>";

    echo "Type de la variable prix: ";
    var_dump($prix);
    echo "<br>";

    echo "Type de la variable nombre: ";
    var_dump($nombre);
    echo "<br><br>";

    // Exercice 3.2 : Opérations Mathématiques

    // 1. Déclarer deux variables avec des valeurs numériques
    $a = 15;
    $b = 4;

    // 2. Effectuer et afficher les résultats des opérations d'addition, de soustraction, de multiplication et de division
    $addition = $a + $b;
    $soustraction = $a - $b;
    $multiplication = $a * $b;
    $division = $a / $b;

    echo "Addition: $a + $b = $addition<br>";
    echo "Soustraction: $a - $b = $soustraction<br>";
    echo "Multiplication: $a * $b = $multiplication<br>";
    echo "Division: $a / $b = " . number_format($division, 2) . "<br><br>";

    // Exercice 3.3 : Calcul de Pourcentage

    // 1. Déclarer une variable pour le montant total et une pourcentage
    $montantTotal = 200;
    $pourcentage = 15; // pourcentage exprimé en pourcentage

    // 2. Calculer et afficher le montant correspondant au pourcentage du total
    $montantPourcentage = ($montantTotal * $pourcentage) / 100;

    echo "Montant correspondant à $pourcentage% de $montantTotal €: " . number_format($montantPourcentage, 2) . " €";
    ?>
</body>
</html>