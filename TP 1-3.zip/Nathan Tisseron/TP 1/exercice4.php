<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 4</title>
</head>
<body>
    <?php
    // Exercice 4 : Utilisation des Structures de Contrôle

    // 1. Affecter les valeurs 150, 50 et 10 aux variables prix_table, prix_armoire et Nombre
    $prix_table = 150;
    $prix_armoire = 50;
    $Nombre = 10;

    // 2. Calculer le prix HT total pour les 10 armoires
    $prix_total_armoires = $prix_armoire * $Nombre;
    echo "Le prix total HT pour 10 armoires est : $prix_total_armoires €";
    echo "<br><br>";

    // 3. Comparer le prix de l'armoire et de la table et afficher quel est le prix le plus élevé
    if ($prix_table > $prix_armoire) {
        echo "Le prix de la table ($prix_table €) est plus élevé que le prix de l'armoire ($prix_armoire €).";
    } elseif ($prix_table < $prix_armoire) {
        echo "Le prix de l'armoire ($prix_armoire €) est plus élevé que le prix de la table ($prix_table €).";
    } else {
        echo "Le prix de la table et de l'armoire sont égaux ($prix_table €).";
    }
    echo "<br><br>";

    // Exercice 4.2 : Structure de Contrôle Switch

    // 1. Déclarer une variable de type chaîne de caractères représentant un jour de la semaine
    $jour_semaine = "Mardi";

    // 2. Utiliser un switch pour afficher un message différent pour chaque jour de la semaine
    switch ($jour_semaine) {
        case "Lundi":
            echo "Aujourd'hui, c'est Lundi. Début de la semaine !";
            break;
        case "Mardi":
            echo "Aujourd'hui, c'est Mardi. Deuxième jour de la semaine !";
            break;
        case "Mercredi":
            echo "Aujourd'hui, c'est Mercredi. Milieu de la semaine !";
            break;
        case "Jeudi":
            echo "Aujourd'hui, c'est Jeudi. Presque la fin de la semaine !";
            break;
        case "Vendredi":
            echo "Aujourd'hui, c'est Vendredi. Dernier jour de travail pour beaucoup !";
            break;
        case "Samedi":
            echo "Aujourd'hui, c'est Samedi. Week-end !";
            break;
        case "Dimanche":
            echo "Aujourd'hui, c'est Dimanche. Profitez de votre repos !";
            break;
        default:
            echo "Jour non reconnu.";
    }
    echo "<br><br>";

    // Exercice 4.3 : Structure de Contrôle Elseif

    // 1. Déclarer une variable représentant une note sur 20
    $note = 15;

    // 2. Utiliser if, else if et else pour afficher une appréciation en fonction de la note
    if ($note >= 16) {
        echo "Très bien";
    } elseif ($note >= 12) {
        echo "Bien";
    } elseif ($note >= 10) {
        echo "Moyen";
    } else {
        echo "Insuffisant";
    }
    ?>
</body>
</html>