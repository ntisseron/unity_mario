<?php
if (!function_exists('somme')) {
    function somme($tableau) {
        $total = 0;
        foreach ($tableau as $element) {
            $total += $element;
        }
        return $total;
    }
}
?>