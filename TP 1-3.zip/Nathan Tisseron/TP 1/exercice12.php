<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 12</title>
    <script>
        // Exercice 12.2 : Formulaire avec Validation JavaScript
        function validateForm() {
            var nom = document.forms["loginForm"]["nom"].value;
            var motDePasse = document.forms["loginForm"]["motDePasse"].value;
            if (nom == "" || motDePasse == "") {
                alert("Veuillez remplir tous les champs.");
                return false;
            }
        }
    </script>
</head>
<body>
    <?php
    // Exercice 12 : Formulaire de Saisie et Validation

    // 1. Construire une page permettant de saisir un nom et un mot de passe.
    echo "<form name='loginForm' action='verification.php' onsubmit='return validateForm()' method='post'>";
    echo "<label for='nom'>Nom:</label>";
    echo "<input type='text' id='nom' name='nom'><br>";
    echo "<label for='motDePasse'>Mot de passe:</label>";
    echo "<input type='password' id='motDePasse' name='motDePasse'><br>";
    echo "<input type='submit' value='Valider'>";
    echo "</form>";
    echo "<br>";

    // Exercice 12.3 : Gestion des Erreurs

    // 1. Modifier le script pour afficher un message d'erreur si le mot de passe est incorrect.
    if (isset($_GET['erreur'])) {
        echo "<p style='color: red;'>Mot de passe incorrect. Veuillez réessayer.</p>";
    }

    // 2. Ajouter une option pour réessayer après une erreur.
    echo "<form action='index.php' method='get'>";
    echo "<input type='submit' value='Réessayer'>";
    echo "</form>";
    ?>
</body>
</html>
