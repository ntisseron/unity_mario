<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercices PHP TP1 - Exercice 7</title>
</head>
<body>
    <?php
    // Exercice 7 : Manipulation des Adresses IP

    // 1. Récupérer l’adresse IP de la machine cliente
    $ipClient = $_SERVER["REMOTE_ADDR"];
    echo "Adresse IP du client : $ipClient<br><br>";

    // 2. Découper l’adresse IP pour déterminer si elle est située en France (IP : 192)
    $ipParts = explode('.', $ipClient);
    if ($ipParts[0] == '192') {
        echo "Adresse IP découpee : " . implode('.', $ipParts) . " (IP potentiellement en France)<br><br>";
    } else {
        echo "Adresse IP complète : $ipClient<br><br>";
    }

    // Exercice 7.2 : Géolocalisation de l'IP

    // 1. Utiliser un service web (par exemple, ipinfo.io) pour obtenir des informations sur l'IP du client
    $ipInfo = @file_get_contents("http://ipinfo.io/{$ipClient}/json");
    if ($ipInfo) {
        $ipData = json_decode($ipInfo, true);

        // 2. Afficher les informations obtenues (pays, région, ville)
        echo "Informations sur l'IP :<br>";
        echo "Pays : " . $ipData['country'] . "<br>";
        echo "Région : " . $ipData['region'] . "<br>";
        echo "Ville : " . $ipData['city'] . "<br><br>";
    } else {
        echo "Impossible d'obtenir les informations de géolocalisation.<br><br>";
    }

    // Exercice 7.3 : Filtrage d'IP

    // 1. Vérifier si l'adresse IP du client est valide
    if (filter_var($ipClient, FILTER_VALIDATE_IP)) {
        echo "Adresse IP valide : $ipClient<br>";
    } else {
        // 2. Si l'adresse est invalide, afficher un message d'erreur
        echo "Erreur : Adresse IP invalide.<br>";
    }
    ?>
</body>
</html>