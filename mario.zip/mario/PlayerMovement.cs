using UnityEngine;

public class MoveCharacter : MonoBehaviour
{
    public float normalSpeed = 10f; // Vitesse de déplacement normale
    public float boostedSpeed = 20f; // Vitesse de déplacement boostée
    public float jumpForce = 4f; // Force de saut
    private bool isGrounded; // Vérifie si le personnage est au sol
    private Rigidbody2D rb; // Référence au Rigidbody2D

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        // Définir la position initiale du personnage sur celle du StartPoint
        GameObject startPoint = GameObject.FindWithTag("StartPoint");
        if (startPoint != null)
        {
            transform.position = startPoint.transform.position;
        }
        else
        {
            Debug.LogWarning("StartPoint non trouvé. Assurez-vous d'avoir un GameObject avec le tag 'StartPoint'.");
        }
    }

    void Update()
    {
        Vector3 movement = Vector3.zero;
        float speed = normalSpeed;

        // Vérifier si la touche Shift est enfoncée pour doubler la vitesse
        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            speed = boostedSpeed;
        }

        // Vérifier si les touches de direction sont enfoncées et ajuster le mouvement
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            movement += Vector3.up;
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            movement += Vector3.down;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            movement += Vector3.left;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            movement += Vector3.right;
        }

        // Appliquer le mouvement horizontal au personnage
        transform.position += movement * speed * Time.deltaTime;

        // Vérifier si la touche espace est enfoncée pour sauter
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            isGrounded = false; // Empêcher les sauts multiples
        }
    }

    // Vérifier si le personnage touche le sol pour réinitialiser isGrounded
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.contacts[0].normal.y > 0.1)
        {
            isGrounded = true;
        }
    }
}
