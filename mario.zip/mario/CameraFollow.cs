using UnityEngine;

public class CameraFollow2D : MonoBehaviour
{
    public Transform target; // Le transform de l'objet à suivre
    public Vector3 offset; // Décalage de la caméra par rapport à l'objet à suivre
    public float smoothSpeed = 0.250f; // Vitesse de lissage

    void FixedUpdate()
    {
        if (target != null)
        {
            Vector3 desiredPosition = target.position + offset; // Position souhaitée de la caméra
            desiredPosition.z = transform.position.z; // Conserver la position z actuelle de la caméra
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed); // Lissage de la transition
            transform.position = smoothedPosition; // Mise à jour de la position de la caméra
        }
    }
}
